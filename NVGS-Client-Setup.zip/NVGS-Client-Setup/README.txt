NVGS CLIENT SETUP

Server: ticketing-system.local
Current LAN address: 192.168.10.102
Ticketing link: https://ticketing-system.local/tickets/
Certificate SHA-256: c4dffa40e0b70e81c7862f54dc36aba5014fde010d911787a96dbd063a98b08b

WINDOWS
1. Open the Windows folder.
2. Double-click "Install NVGS on Windows.cmd".
3. Approve the Windows Administrator prompt and click Yes.

UBUNTU
1. Open the Ubuntu folder.
2. Run "Install NVGS on Ubuntu.run" as a program.
   If the file manager opens it as text, open Terminal in this folder and run:
     bash "Install NVGS on Ubuntu.run"
3. Type INSTALL and enter the Ubuntu administrator password.

The installer trusts only the public NVGS CA, maps the friendly name to the
current LAN address, and creates an NVGS Ticketing desktop shortcut. It never
contains the CA private key, server secrets, or user passwords.

If the server receives a different DHCP address, rebuild this package and run
the installer again on each client. A DHCP reservation or approved internal
DNS record removes that repeated step.
